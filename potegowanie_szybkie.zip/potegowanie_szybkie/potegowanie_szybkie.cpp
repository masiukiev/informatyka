#include <iostream>
using namespace std;
int funkcja(int a, int n, int d);
int main()
{
    int a;
    int n;
    int d = 1;

    cout << "Podaj podstawe: ";
    cin >> a;
    cout << "Podaj wykladnik: ";
    cin >> n;

    cout << a << " do potegi " << n << " wynosi " << funkcja(a, n, d);

}
int funkcja(int a, int n, int d) {
    while (n > 0) {
        if (n % 2 == 1) {
            d = d * a;
        }
        a = a * a;
        n = n / 2;
    }
    return d;

}